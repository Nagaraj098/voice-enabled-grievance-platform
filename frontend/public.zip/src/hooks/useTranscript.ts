"use client";

import { useEffect, useState } from "react";
import { Message } from "@/types/chat";

export function useTranscript() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isThinking, setIsThinking] = useState(false);

  useEffect(() => {
    const ws = new WebSocket("ws://localhost:8000/ws/transcript");

    ws.onopen = () => {
      console.log("WebSocket connected");
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);

        console.log("Received:", data);

        switch (data.type) {
          case "agent_thinking":
            setIsThinking(true);
            break;

          case "user_transcript":
            setIsThinking(false);

            setMessages((prev) => [
              ...prev,
              {
                id: crypto.randomUUID(),
                role: "user",
                text: data.text,
                timestamp: Date.now(),
              },
            ]);
            break;

          case "agent_response":
            setIsThinking(false);

            setMessages((prev) => [
              ...prev,
              {
                id: crypto.randomUUID(),
                role: "agent",
                text: data.text,
                timestamp: Date.now(),
              },
            ]);
            break;

          default:
            console.log("Unknown WS message:", data);
        }
      } catch (err) {
        console.error("Invalid WS message:", event.data);
      }
    };

    ws.onerror = (err) => {
      console.error("WebSocket error:", err);
    };

    ws.onclose = () => {
      console.log("WebSocket closed");
    };

    return () => {
      ws.close();
    };
  }, []);

  return { messages, isThinking };
}